/*
JES v0.7.5-full Copyright 2013 http://whattheframework.org/jes/license
wtf-js-merged @ 2013-12-06 10:05:13
*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {};
	u.version = 0.8;
	u.bug = function() {};
	u.nodeId = function() {};
	u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){};}
}
