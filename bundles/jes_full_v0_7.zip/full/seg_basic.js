/*
JES v0.7-full Copyright 2013 http://whattheframework.org/jes/license
wtf-js-merged @ 2013-04-23 11:36:03
*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {}
	u.version = 0.7;
	u.bug = function() {}
	u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){}}
}
