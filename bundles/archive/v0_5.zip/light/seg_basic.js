/*
JES v0.5-light Copyright 2013 http://whattheframework.org/jes/license
wtf-js-merged @ 2013-04-17 10:24:01
*/

/*u.js*/
var u, Util = u = new function() {}
u.version = 0.5;
u.bug = function() {}
u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){}}
