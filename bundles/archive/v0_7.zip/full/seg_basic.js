/*
JES v0.7-full Copyright 2013 http://whattheframework.org/jes/license
wtf-js-merged @ 2013-06-26 04:12:51
*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {}
	u.version = 0.8;
	u.bug = function() {}
	u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){}}
}
