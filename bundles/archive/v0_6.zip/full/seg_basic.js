/*
JES v0.6-full Copyright 2013 http://whattheframework.org/jes/license
wtf-js-merged @ 2013-04-18 04:57:33
*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {}
	u.version = 0.6;
	u.bug = function() {}
	u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){}}
}
