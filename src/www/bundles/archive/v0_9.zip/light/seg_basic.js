/*
Manipulator v0.9-light Copyright 2015 http://manipulator.parentnode.dk
js-merged @ 2015-02-21 09:12:14
*/

/*seg_basic_include.js*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {};
	u.version = 0.9;
	u.bug = u.nodeId = u.exception = function() {};
	u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){};}
}

