
// script loader - if object is initialialized and not already included - ínclude and initialize
// what abaut segments??
Util.Objects.Modules = u.o.m = new function() {

	this.load = function(script) {

		// make XMLRequest to check for url validity
		// load if available - responder in modult
		
	}

	this.loaded = function(object) {

		// keep u.s.loaded(objectname) with every object - if possible use inherritance of some sort
		
	}

}
