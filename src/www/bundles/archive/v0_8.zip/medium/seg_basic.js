/*
Manipulator v0.8-medium Copyright 2014 http://manipulator.parentnode.dk
wtf-js-merged @ 2014-05-13 10:17:13
*/

/*seg_basic_include.js*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {};
	u.version = 0.8;
	u.bug = function() {};
	u.nodeId = function() {};
	u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){};}
}

